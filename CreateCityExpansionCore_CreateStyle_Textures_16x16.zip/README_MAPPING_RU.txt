CreateCityExpansionCore — Create-style industrial textures

MAIN DROP-IN PATHS
------------------
assets/createcityexpansioncore/textures/item/
assets/createcityexpansioncore/textures/block/

Размер предметных текстур: 16x16 PNG RGBA (как у стандартных item sprites Create).
Масштабирование выполнено nearest-neighbor, прозрачность сохранена.

СООТВЕТСТВИЕ
-------------
industrial_coke.png — Промышленный кокс
steel_billet.png — Стальная заготовка
steel_plate.png — Стальная плита
structural_beam.png — Конструкционная балка
industrial_fastener_pack.png — Комплект промышленного крепежа
reinforcement_bundle.png — Арматурный пакет
rail_profile.png — Рельсовый профиль
sleeper_pack.png — Пакет железнодорожных шпал
dry_concrete_mix.png — Сухая бетонная смесь
ceramic_compound.png — Керамическая масса
technical_ceramic.png — Техническая керамика
copper_busbar.png — Медная силовая шина
heavy_machine_frame.png — Рама тяжёлой машины
industrial_control_unit.png — Промышленный блок управления
power_distribution_module.png — Силовой распределительный модуль
incomplete_heavy_machine_frame.png — Служебная незавершённая рама
incomplete_industrial_control_unit.png — Служебный незавершённый блок управления

block/reinforced_concrete.png — Железобетон, 16x16 плоская block texture.

В preview/reinforced_concrete_item_icon.png лежит также изометрическая иконка железобетонного блока из арт-набора; она не подключается автоматически и дана как опциональный референс.

preview/preview_16x16_x10.png — увеличенный nearest-neighbor preview всех 18 ассетов.
